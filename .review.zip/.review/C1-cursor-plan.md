# C1: custom cursor plan (PLAN ONLY, no code written)

Branch `phase-c0-roadmap`, from `main` at `cb27974`. Baseline gates: all 7 exit 0, 146 e2e, `157 KB, +0 KB`.
Costs marked **estimate** are not measured; I measure them when it is built.

---

## 1. Current state: did a cursor ever exist?

**No cursor code has ever existed in `src/`, `tests/` or `content/`.**

- `grep -i cursor` over `src`, `tests`, `content` (excluding the plain `cursor-pointer` utility, used 4 times) finds nothing.
- Git history (all branches): the only commit that contains cursor code is `cf450ba docs: add plan, rules and reference`, which added `PLAN.md` and the template. No commit under `src/` mentions it.
- `PLAN.md` line 199 lists it as planned work, and Phase 3 item 8 (`CursorRing`, `Magnetic`, `Spotlight`) was never started: `| Cursor ring, magnetic buttons, card spotlight | CursorRing, Magnetic, Spotlight | Fine pointer + motion allowed only |`.
- `src/hooks/useFinePointer.ts` (Phase 3.1) exists for exactly this and is unused by any cursor. It returns `false` during server rendering and for `(hover: hover) and (pointer: fine)` otherwise.

So it is not "hidden"; it was simply never ported.

**What the template (`reference/portfolio-template.html`) does** (the behavior I would port, with its flaws):

```css
.cursor{position:fixed;left:0;top:0;width:34px;height:34px;margin:-17px 0 0 -17px;border:1px solid var(--ink);border-radius:50%;pointer-events:none;z-index:var(--z-cursor);opacity:0;transition:opacity .3s,width .25s ...;mix-blend-mode:difference;border-color:#fff}
.has-cursor .cursor{opacity:1}
.cursor.big{width:64px;height:64px;margin:-32px 0 0 -32px;background:rgba(255,255,255,.18)}
```
```js
if (!fine) return;
root.classList.add('has-cursor');
var ring = document.querySelector('.cursor'), rx = mx, ry = my;
(function follow(){ rx += (mx - rx) * .18; ry += (my - ry) * .18;
  ring.style.transform = 'translate3d(' + rx + 'px,' + ry + 'px,0)'; requestAnimationFrame(follow); })();
document.addEventListener('pointerover', function(e){
  ring.classList.toggle('big', !!e.target.closest('a,button,.win-bar,.chip,.stk')); });
```

Flaws I would not copy:
1. **The animation loop never stops**, even when the pointer is idle (always burns a frame).
2. **It ignores reduced motion** (it only checks the pointer type), so the ring always lags.
3. The ring sits at the top-left of the page, not hidden, until the first move (opacity depends only on `has-cursor`).
4. Nothing hides it over text fields, when the pointer leaves the window, or in forced-colors mode.
5. `mix-blend-mode: difference` gives unpredictable colors on a colored surface (the green primary button).

Good news: the template does **not** hide the native cursor (no `cursor: none` anywhere), so it is already option (a).

---

## 2. Options and recommendation

| | (a) Keep native cursor, add a follower ring (**recommended**) | (b) Replace the native cursor |
|---|---|---|
| How | A decorative, `pointer-events: none` ring that trails the real pointer. The OS cursor is untouched. | Hide the OS cursor (`cursor: none`, set by JS only) and draw our own. |
| Low-vision users with enlarged or high-contrast OS cursors | Their cursor stays exactly as they set it; the ring is extra and can be switched off by forced colors or reduced motion. | **We override their OS setting.** A custom cursor does not follow the OS pointer size or color, and any lag makes the drawn pointer differ from where the click lands. |
| Click accuracy | The real hotspot is always the truth. | The drawn pointer lags the true hotspot, so people can mis-click. |
| Text fields | Native I-beam kept for free. | We must re-implement the I-beam and every other state. |
| Failure mode | If JS fails, nothing changes. | If our JS dies after hiding the cursor, the user has **no cursor**. This is why a CSS-only `cursor: none` must never exist. |
| Risk | Low | High |

**Recommendation: (a).** The ring is an accent, not a replacement for the pointer. One caveat for low-vision users: with a very large OS cursor (which extends down and right of the hotspot) a 28 px ring centered on the hotspot is smaller than their cursor; it never hides it, so this is harmless, but I will say so in the PR.

---

## 3. Rules the design must meet, and how each is tested

| # | Rule | Design | Test |
|---|---|---|---|
| R1 | Only on `(pointer: fine) and (hover: hover)`; nothing on touch | Render the ring only when `useFinePointer()` is true (it is `false` on the server, so the element is never in the HTML). No listeners are added otherwise. | e2e with a touch device context (`hasTouch`, `isMobile`): no `[data-cursor-ring]` element exists. |
| R2 | JS off, or before JS starts: native cursor fully normal; **never `cursor: none` from CSS alone** | In option (a) the plan has no `cursor: none` at all. The ring element does not exist until after hydration. | e2e with JS off: computed `cursor` on `body`, a link and a button are the normal `auto` / `pointer`, and no ring element exists. |
| R3 | Reduced motion: no lag or spring (snap, or off; I recommend **one**) | **Recommend OFF** (not rendered; also a CSS `display: none` under `prefers-reduced-motion: reduce`, so a mid-session change hides it). Reason: reduced-motion users get nothing extra to track, the code path is simplest, and it matches how the hero intro behaves. The alternative (a snapping ring) adds a duplicate pointer mark without lag; I would only choose it if you want the hover-size feedback for these users (Q2). | e2e with `reducedMotion: "reduce"`: no ring element, and a pointer move produces no ring. |
| R4 | Text inputs and textareas keep the native I-beam | Native cursor is never hidden, so the I-beam is untouched. The ring **hides** over `input, textarea, select, [contenteditable]` so it does not sit on the caret. | e2e: hover and focus the contact `textarea`: its computed `cursor` is `text` and the ring is hidden. |
| R5 | `pointer-events: none`; clicks always reach what is underneath | `pointer-events: none` on the ring. | e2e: move onto a nav link and click at that point: the hash changes. `document.elementFromPoint` there returns the link, never the ring. |
| R6 | Hidden in forced-colors mode and when the pointer leaves the window | `@media (forced-colors: active) { display: none }`. A `mouseout` with no `relatedTarget` (and `blur`) hides it; the next move shows it again. | e2e with `forcedColors: "active"`: ring not displayed. e2e: dispatch the leave event: state is hidden; move: visible again. |
| R7 | States over links/buttons, over text, while pressed | See "States" below. | e2e: hover a link: `data-state="interactive"`; hover a paragraph: `text`; `pointerdown`: pressed; back to default on `pointerup`. |
| R8 | Theme-aware colors, light and dark | Ink-colored border with a thin background-colored halo (`var(--ink)` and `var(--bg)`), so it reads on cream, on dark, and on the green button. No `mix-blend-mode`. | e2e in both `colorScheme`s: the ring's border color equals the `--ink` token's computed value, and the halo equals `--bg`. |
| R9 | Performance: one element, transform only, `requestAnimationFrame`, passive listeners, no React state per move, no layout reads in the loop | See "Performance design" below. | Unit tests with a React `Profiler` (zero re-renders across 200 moves), a spy on `getBoundingClientRect` and `getComputedStyle` (zero calls during moves), and a fake-`requestAnimationFrame` test that the loop stops when the ring has caught up. |
| R10 | No hydration warnings; the dev-console test stays clean | Server renders nothing for the ring; the client adds it after hydration (same `useSyncExternalStore` pattern as `useFinePointer`, whose server snapshot is `false`). | The existing `console.spec.ts` (runs against `next dev` too) gets a step that moves the mouse over the page and fails on any console error or warning. |

### States

| State | What changes | Detection |
|---|---|---|
| Default | Ring about 28 px, 1.5 px ink border, background-colored halo, full follow | - |
| Over links and buttons (`a[href], button, summary, [role="button"], label, select`) | Ring **grows** (scale about 1.8) with a faint ink fill | `pointerover` + `closest()` once per element change, not per move |
| Over text (`p, h1-h6, li, dd, dt, blockquote`) | Ring **shrinks** (scale about 0.5) and softens, so the native I-beam stays readable | same |
| Pressed | Ring scales to about 85 percent of its current size | `pointerdown` / `pointerup` |
| Hidden | Over inputs, textareas and selects; when the pointer leaves the window; before the first move; forced colors; reduced motion; touch | as above |

Size and fill change through CSS `transition` on the individual CSS `scale` and `opacity` properties. JS only writes the individual CSS `translate` property each frame, so it is still a single element and **transform-only** (no `left`/`top`/`width` changes).

### Performance design

- **One element.** A single fixed `div` (`aria-hidden`).
- **`pointermove`** (passive, on `document`) only stores `x, y` in a closure variable and, if no frame is already scheduled, asks for one `requestAnimationFrame`. **No React state, no DOM reads.**
- **The frame** eases toward the stored point (about 0.2 per frame) and writes `element.style.translate`. When the remaining distance is under 0.1 px it snaps to the point and **stops scheduling frames**, so an idle pointer costs nothing (the template's loop never stops).
- **No layout reads in the loop:** no `getBoundingClientRect`, no `getComputedStyle`, no `offsetWidth`. State detection happens on `pointerover` (once per element change) and uses `closest()` with a fixed selector, which reads no layout.
- `visibilitychange` cancels any pending frame; listeners are removed on unmount.
- Position starts hidden until the first `pointermove`, so it never sits at (0, 0).
- **Hit-testing note:** it is a fixed element above the status bar and the mobile menu, with `pointer-events: none`, so it can never block anything.

---

## 4. Implementation shape

- **One Client Component, mounted once in `src/app/layout.tsx`** (after `Footer`, outside the page), not in each section. One instance for the whole document, not remounted on route changes, and not part of the hero Server Component. It returns `null` until `useFinePointer()` is true and motion is allowed.
- **Files:**
  - `src/components/interactive/CursorRing.tsx` (about 80 lines; reuses the existing `useFinePointer` and the existing `useReducedMotion` import, so no new dependency).
  - `src/app/globals.css`: ring base styles, the states, the forced-colors, reduced-motion and print hides.
  - `src/app/layout.tsx`: one import and one element.
  - `tests/unit/cursor-ring.test.tsx`, `tests/e2e/cursor.spec.ts`, and one extra step in `tests/e2e/console.spec.ts`.
- **Cost (estimate, to be measured):** JS about +0.8 to +1.2 KB gzipped (the component and its listeners; the hook and `useReducedMotion` are already in the bundle), CSS about +0.3 to +0.5 KB gzipped, HTML +0 (nothing rendered on the server). That would put first-load JS near 158 KB against the 157 KB baseline (tolerance 2 KB). Per your budget rule I would not shrink the idea for size; if the measured result is over tolerance I raise the baseline with a `bundle-budget.json` history entry saying why. I would also report LCP/CLS back to back against `main` (the B1 method). Because the ring appears only after hydration, I expect LCP to be unchanged, which I will check rather than assume.

---

## 5. Tests, each with the mutation that must make it fail

Every mutated run must fail and the restored run must pass (outputs saved, files restored byte for byte), as in B1.

| # | Test | Mutation that must make it fail |
|---|---|---|
| T1 | **Absent on touch** (touch context: no ring element) | Remove the fine-pointer gate so the ring renders on touch |
| T2 | **Absent with JS off**, and native `cursor` values normal on `body`, links, buttons | (a) Render the ring in the server HTML; (b) add an unconditional `* { cursor: none }` |
| T3 | **Follows the pointer within N px** after a move: ring center within 2 px of the pointer after 400 ms | Set the easing factor so low it cannot converge (for example 0.01), and separately write the wrong coordinates |
| T4 | **A click on a link under the cursor still navigates** (hash changes; `elementFromPoint` is the link) | Remove `pointer-events: none` from the ring |
| T5 | **Input keeps the native caret/I-beam:** `textarea` computed `cursor` is `text`; ring hidden over it | Add `textarea { cursor: none }`; and separately remove the input check so the ring shows over it |
| T6 | **Reduced motion:** no ring | Ignore the reduced-motion check |
| T7 | **Forced colors:** ring `display: none` | Delete the forced-colors CSS rule |
| T8 | **Leaves the window:** hidden, then visible again on the next move | Remove the leave handler |
| T9 | **States:** link, text, pressed, default | Break the `closest()` selector for links |
| T10 | **Theme colors:** border equals `--ink`, halo equals `--bg`, in light and dark | Hard-code a white border |
| T11 | **No React state per move** (Profiler: 0 re-renders over 200 moves) | Store the position in `useState` |
| T12 | **No layout reads** in the loop (spies see 0 calls to `getBoundingClientRect` / `getComputedStyle` / `offsetWidth`) | Add a `getBoundingClientRect()` call to the frame |
| T13 | **Loop stops when idle** (fake `requestAnimationFrame`: no new frame once converged) | Always reschedule |
| T14 | **No console errors or warnings** in the dev-console project while moving the mouse | Render the ring during server rendering (hydration mismatch) |

Not tested (and I will say so in the PR): how it feels on a real OS cursor, and behavior with a real enlarged OS cursor. Playwright does not draw the OS cursor.

---

## 6. Evidence you will get after implementation

- **Videos at 1440x900, light and dark** (Playwright `recordVideo`), the mouse moving over: a nav link, a primary button, a heading and paragraph, and the contact `textarea`, plus leaving the window.
- **Limitation, stated up front:** Playwright recordings do **not** include the OS cursor, so the videos show the ring (and its states, and it hiding over the input) but not the native pointer. To show the native pointer next to the ring I would need a screen recording on your machine or a manual check; I will say that in the report instead of faking it.
- A few still frames of each state (default, interactive, text, pressed, hidden) in both themes.
- All 7 gates raw, every mutation's fail and pass output, LCP/CLS back to back against `main`, CSS/HTML/JS size added, and the bundle line.

---

## 7. Open questions for you

1. **Option (a) (keep the native cursor, add a ring)** as the default: confirmed? (I recommend against (b).)
2. **Reduced motion:** **off** (my recommendation) or a snapping ring?
3. **Over text** the ring shrinks to keep the I-beam readable. Fine, or should it stay the same size?
4. **Color style:** ink border with a background halo (my recommendation, works on every surface) or the template's white `mix-blend-mode: difference` look?
5. **Scope:** `PLAN.md` bundles `CursorRing`, `Magnetic` buttons and a card `Spotlight` in one line. Do you want only the ring in PR 1 (my recommendation), with the others as separate decisions?
6. **An off switch:** should visitors have a way to turn the ring off (for example a toggle or the command palette later), beyond reduced motion and forced colors?
7. **Dialogs and menus:** the ring stays above the status bar, the mobile menu and the future project-details dialog (so you can still see where the pointer is). OK?
8. **Pressed state** is a small shrink; do you also want a click ripple (I would not add one)?
