# C-roadmap: redesign spec mapped onto the current site

Branch `phase-c0-roadmap`, from `main` at `cb27974` (merge of PR #9). Baseline gates: all 7 exit 0, 146 e2e passed, bundle `First-load JS for /: 157 KB, baseline 157 KB, +0 KB` (`baseline-gate-output.txt`). **No repo file was changed.** Nothing here was measured except where it says "measured"; sizes (S/M/L) are my judgment.

**Rules I applied.** Content comes only from `content/*.ts`; anything in the spec that is not there is marked **not in content, needs my confirmation** and I did not add it. The performance budget is deferred, so I did not reject anything for size, but I would never remove the bundle test or the LCP/CLS checks, and I report the measured cost of each PR and raise a baseline only with a history entry.

## 0. The short version

- **Most of the spec already exists** in a better form: window chrome, project cards, marquees, FAQ accordion, no fake status icons, no testimonials, theme tokens, CTAs, contact, and a one-time intro.
- **What is genuinely missing:** a project **filter**, **hover demos**, a **details dialog** opened from a window dot, a **second skills marquee row** going the other way, **GitHub/LinkedIn icons in the bar**, and a few small motion tokens (hover lift).
- **What I recommend skipping:** a thin transparent-to-blur nav (the current floating pill is deliberate and approved), a hero collage that would replace the 3D cube, a window chrome on the Experience section, and the Vite / MUI / Shadcn / Framer Motion stack.
- **Big finding on content:** the spec's five projects (SpendWise, MindMitra, Course Tracker, Tutorly, iPharmaAI 483) **are not in `content/projects.ts` at all**, and its "one role" Experience section contradicts the 5 roles in `content/experience.ts` (section 3).
- **Motion library: not needed anywhere.** See section 5.

## 1. Gap table (one row per spec item)

Legend for "Needs from you": **assets** = screenshots or videos; **content** = a fact only you can confirm; **decision** = a design choice; **token** = an API credential; **-** = nothing.

### Spec section 0: assumptions and constraints

| Spec item | Current state | Rec. | Reason | Size | Needs from you |
|---|---|---|---|---|---|
| 0.1 Assumed section order Nav, Hero, About, Projects, Skills, Experience, Contact | `src/app/page.tsx`: `<Hero /> <Marquee/> <About /> <Work /> <Research /> <Highlights /> <Experience /> <Log /> <Faq /> <Contact />` | **done** | The site already has this order plus Research, Highlights, Log, FAQ. | - | - |
| 0.2 Perf budget: no autoplay-on-load video, lazy-load below the fold, Lighthouse 90+ | No video anywhere. `bundle-budget.json` + `tests/e2e/bundle.spec.ts` guard first-load JS (157 KB, tolerance 2 KB, warn at 170). CI (`.github/workflows/ci.yml`) runs encoding, content:check, format, typecheck, lint, test, build, e2e. **No Lighthouse in CI** (PLAN.md line 342 lists "Lighthouse CI budgets" for a later phase). | **adapt** | Keep the bundle test and the LCP/CLS checks I run per PR. Budget is deferred, so no idea is cut for size. Lighthouse CI stays a separate optional PR (PR 10). | S | decision (when to add LHCI) |
| 0.3 Keep your colors and typography | Tokens in `src/app/globals.css`: `--bg:#f1eee3; --card:#faf8f1; --ink:#141a14; --accent:#2f7a4b ...`, light and dark. | **done** | - | - | - |
| 0.4 Window chrome must be functional, not decorative | `Window.tsx` header renders `<TrafficLights />` (3 `aria-hidden` dots, no behavior). Comment in `Window.tsx`: "Static for now. Drag, tilt and working traffic lights arrive in Phase 3." | **adapt** | Your decision removes red and yellow; green becomes the one real control (see 1.7). | M | decision (section 7, Q1 to Q3) |

### Spec section 1: global design system

| Spec item | Current state | Rec. | Reason | Size | Needs from you |
|---|---|---|---|---|---|
| 1.1 `<WindowCard>` with props `title, variant, onClose, onExpand, children` | `src/components/primitives/Window.tsx`: props `title, meta, screen, screenFrame, decorativeScreen, caption, children, className`. Used by `ProjectWindow` and the About bento. | **adapt** | Already the reusable window. Drop `onClose` and `variant` (red dot is out; layouts are already driven by `screenFrame`). Add an optional `onOpen`-style slot for the green dot only. | S | - |
| 1.2 Markup: header bar, 3 dot buttons, filename-style monospace title | `<header className="flex select-none items-center gap-3.5 border-b border-line px-4 py-3 font-mono text-[.76rem] text-muted">` + `<TrafficLights />` + `<span className="min-w-0 flex-1 truncate">{title}</span>`; titles come from `content/projects.ts` `window: "sustainability-tracker.app"`. | **done** | - | - | - |
| 1.3 Tailwind classes `rounded-lg border shadow-md bg-white dark:bg-zinc-900` | `rounded-[20px] border border-line bg-card`, theme through CSS variables (no `dark:` classes). | **done** | Tokens, not hard-coded colors (CLAUDE.md rule). Do not copy the literal classes. | - | - |
| 1.4 Framer Motion entrance (fade + y) and `whileHover` scale 1.02, spring | Entrance: `Reveal` (IntersectionObserver + `element.animate`) already fades sections in, with reduced-motion handling. Hover: `Window` only has `hover:border-line-strong`. No hover scale. | **adapt** | Add a CSS-only hover lift (scale 1.02) gated by `(hover: hover) and (prefers-reduced-motion: no-preference)`. A spring feel can come from a CSS `linear()` easing. **No library.** | S | - |
| 1.5 Red dot collapses the card | Not present. | **skip** | Out by your decision. | - | - |
| 1.6 Yellow dot minimizes to header-only | Not present. | **skip** | Out by your decision. | - | - |
| 1.7 Green dot opens a fullscreen project detail view | Not present. `ProjectWindow` shows an inline `<details>` ("Deep dive") with `project.deep`; `features`, `metrics`, `links` exist in content. | **adapt** | Green dot = "open project details" only, as a real `<button>` with a 44 px hit area, opening a Radix Dialog (focus trap, Esc, `aria-modal`; `radix-ui` is already used by `MobileMenu`). The inline `<details>` stays as the no-JS and touch path. Conflict with the touch rule: see Q2. | M | decision |
| 1.8 Motion tokens: hover scale 1.02 to 1.05; spring 300/24; stagger 0.08; marquee 30 to 40 s linear, pause on hover | Marquee already: `animation: marquee-slide 32s linear infinite` and `.marquee-track:hover > ul { animation-play-state: paused }` (and each strip has a pause button from PR #8). No stagger tokens; no shared durations. | **adapt** | Add a few CSS variables for hover scale and easing, and a word-stagger style that already exists in the hero intro (18 ms). Marquee part is **done**. | S | - |

### Spec section 2: nav / menu bar

| Spec item | Current state | Rec. | Reason | Size | Needs from you |
|---|---|---|---|---|---|
| 2.1 Sticky thin (~40 px) bar styled like a system status bar | `BarPill.tsx`: `fixed inset-x-0 top-0 z-50 ...` with an inner `rounded-full border border-line bg-glass ... backdrop-blur-[14px]`, about 58 px tall, max width 70 rem. | **skip** | The floating glass pill is the approved design and carries the clock and the now-playing chip. A thin full-width bar would be a redesign for no new function. | - | decision (confirm skip) |
| 2.2 Left: name/initials home link. Right: section links + GitHub/LinkedIn icons | `Brand` (initials badge `ms` + city + clock) at left; `<nav>` section links in the middle; right side has availability dot, mobile menu button and theme toggle. GitHub/LinkedIn exist only in `MobileMenu` and the Contact section buttons. | **adapt** | Add two icon links (links already in `content/site.ts`: `github`, `linkedin`). Watch the 760 to 1100 px range, where the bar is already full. | S | - |
| 2.3 Skip fake wifi/bluetooth/battery icons | None present. | **done** | - | - | - |
| 2.4 Transparent to blur plus border after 40 px of scroll (`useScroll`) | No scroll listener; the glass pill is always blurred. | **skip** | The pill already floats over content with blur; a transparent state at the top would reduce contrast over the hero text. Would also need JS or scroll-timeline CSS (Firefox lacks it). | S | decision (confirm skip) |

### Spec section 3: hero

| Spec item | Current state | Rec. | Reason | Size | Needs from you |
|---|---|---|---|---|---|
| 3.1 Keep headline and intro | `Hero.tsx`; headline in `content/site.ts`: "I build products that ship, and systems that hold up." With the B1 lights-out intro. | **done** | - | - | - |
| 3.2 2 to 3 layered, slightly rotated WindowCards (collage) | `Hero.tsx` right column is `<Cube />`: `// Decorative and static.` CSS 3D cube with faces `["React","Django","FastAPI","Celery","Redis","NEAT"]`. | **skip** | Replacing the cube is a design reversal, not a missing feature. Optional later. | L | decision |
| 3.3a Card: terminal/code snippet | Missing. | **skip (defer)** | Only worth it with a real snippet from your code, which is a content decision. | S | content |
| 3.3b Card: live GitHub stats | Missing. No GitHub token in `src/env.ts`, no `src/services/github.ts`. Spec says "live". | **skip (defer)** | Needs a service, a token, caching and rate limiting; the numbers would be new facts not in `content/`. I would only do it if you want it. | M | token + decision |
| 3.3c Card: muted hover-only clip, 5 s or less | Missing; `Project.media` is `{ src, alt }`, images only. | **adapt** (see 5.3) | Same mechanism as the project hover demos. | M | assets |
| 3.4 CTAs "View Projects / Resume / Contact" | `Hero.tsx`: primary "See projects" (`#work`), "Résumé" (`site.links.resume`), "Email me" (`mailto:`). | **done** | Same three actions, different wording. | - | - |

### Spec section 4: About

| Spec item | Current state | Rec. | Reason | Size | Needs from you |
|---|---|---|---|---|---|
| 4.1 Plain text and photo, no window chrome | `About.tsx` is a bento of `Window` and `Card` blocks (facts, stats, toolbox); `avatar: "/assets/Icon.jpeg"` in content. | **skip** | Already richer than the spec. Removing chrome would be a regression. | - | - |
| 4.2 Optional editor-style card with the bio as a code comment | Missing. | **skip** | Spec calls it a nice-to-have, and the current bento already uses windows. | S | - |

### Spec section 5: projects

| Spec item | Current state | Rec. | Reason | Size | Needs from you |
|---|---|---|---|---|---|
| 5.1 Each project is a project WindowCard with a filename-style title | `ProjectWindow.tsx`: `<Window title={project.window} meta={project.period} screen={screen} ...>`. Titles like `sustainability-tracker.app`, `profolio.app`, `platformer.exe`. | **done** | The pattern exists. **The five spec projects are not in content** (section 3). | - | content |
| 5.2 Default: static screenshot, no video loaded | `media` PNGs in `public/assets/` for NexGen, Wanderlust, AI Society, shooter; mock "visual" screens (`bars`, `rows`, `lesson`, `resume`, `chat`) for the rest, marked "sample data". | **done** | - | - | assets (real screenshots for the 5 mock projects would replace the sample visuals) |
| 5.3 Hover swaps to a lazy-loaded muted looping `<video>` | Missing. | **adapt** | Create the `<video>` only on first hover, fine pointer only, never on touch or with reduced motion; add `media.video` to the content schema. | M | assets (videos) |
| 5.4 Green dot modal: full description, stack tags, GitHub link, live link | Missing (see 1.7). Content already has `deep`, `features`, `stack`, `metrics`, `links.live/code/paper`. | **adapt** | Same as 1.7. | M | decision |
| 5.5 Filter toggle `All / Full-stack / AI-ML / Frontend` | Missing. `Work.tsx` renders every visible project. **`Project` has no `category` field.** | **adapt** | Needs a category per project from you (a content decision). Can be built without JS using radio inputs and `:has()`. | M | content (categories) |

### Spec section 6: skills

| Spec item | Current state | Rec. | Reason | Size | Needs from you |
|---|---|---|---|---|---|
| 6.1 Marquee ticker, two rows scrolling opposite ways | `page.tsx`: one tech marquee (`marquee` list, 10 items: `Python ... Docker`) under the hero; the "receipts" strip (`Highlights`) runs the other way but holds different content. Marquee is pure CSS, with a pause button and a static layout for reduced motion/no JS. | **adapt** | Add a second tech row, reversed, from skills **already in `content/skills.ts`** (for example the Databases and Testing groups). `Marquee` already supports reverse via the `receipts` variant class. | S | decision (which items) |
| 6.2 Content "pulled from your actual stack" (React, Vite, Tailwind, Framer Motion, Redux Toolkit, TanStack Query, Node/Express, FastAPI, Django, PostgreSQL, Redis, Docker, Qdrant/RAG, JWT) | `content/skills.ts` has React, Next.js, Tailwind CSS, Node.js, Express, FastAPI, Django REST Framework, PostgreSQL, Redis, Docker, Qdrant, RAG pipelines, JWT. **Not in content:** Redux Toolkit, TanStack Query, Framer Motion; Vite appears only as a Study Tracker stack item. | **adapt** | Use only what is in content (section 3). | - | content |
| 6.3 Pure CSS, no animation library | Already pure CSS. | **done** | - | - | - |

### Spec sections 7 to 9: experience, FAQ, contact

| Spec item | Current state | Rec. | Reason | Size | Needs from you |
|---|---|---|---|---|---|
| 7.1 One WindowCard per role; "currently just NexGen" | `Experience.tsx`: a vertical timeline `<ol>` of 5 entries from `content/experience.ts` (Praverse Tech, 2 NexGen roles, PUAISO, CDC). | **skip** | Spec is stale (section 3) and itself says not to force chrome here. Candidate instead: **B3** sticky card stack (section 4). | - | content (confirm stale) |
| 8.1 FAQ accordion (Shadcn or Framer) | `Faq.tsx`: native `<details name="faq">` with a CSS plus/minus; 7 questions in `content/faq.ts`. | **done** | Native accordion needs no library and works without JS. | - | - |
| 9.1 Contact: email, GitHub (`Rabbitshah`), LinkedIn, resume | `Contact.tsx`: form, email button, Copy email, GitHub, LinkedIn. `content/site.ts` github is `https://github.com/Rabbitshah`. Resume link is a Google Drive URL with `TODO(content)` to move to `/resume.pdf`. | **done** | - | - | assets (the resume PDF, already a TODO) |
| 9.2 Skip testimonials | None present. | **done** | - | - | - |

### Spec section 10 and the stack header

| Spec item | Current state | Rec. | Reason | Size | Needs from you |
|---|---|---|---|---|---|
| 10.1 Build order 1 to 6 | See section 6 for the proposed PR order. | **adapt** | Most steps are already done; the order is rebuilt around what is missing. | - | - |
| 10.2 Run Lighthouse after each step; cut anything over about 10 points | Not set up. | **adapt** | Per PR I will report bundle line, LCP/CLS (same method as B1) and CSS/HTML size. Lighthouse CI as its own PR. | S per PR | - |
| Target stack: React + Vite + Tailwind + Framer Motion + MUI/Shadcn | Next.js App Router, Server Components, Tailwind, `radix-ui`, `motion` (used only for `useReducedMotion` in `Reveal.tsx` and `CountUp.tsx`). | **skip** | Fixed decision: keep the current stack. | - | - |

## 2. Roadmap candidates that are not spec items

| Candidate | Current state | Rec. | Reason | Size | Needs from you |
|---|---|---|---|---|---|
| **B2 rolling-text hover** on nav and contact-section buttons | Nav links: `StatusBar.tsx` `<Link className="inline-flex min-h-11 ... hover:bg-bg-2 hover:text-ink">`. Buttons: `Button.tsx`. Nothing rolls. (Note: the footer has no GitHub/LinkedIn buttons; they are in `Contact.tsx`.) | **adopt** | Server-rendered `RollLink`: two stacked copies, CSS transform on hover/focus-visible, copy marked `aria-hidden`, gated by `(hover: hover)` and no-preference. About 0 KB JS. | S | decision (also on the primary CTAs?) |
| **B3 sticky card stack** for Experience (was in the earlier Part B list; not mentioned in this prompt) | Plain timeline. | **adopt (decision)** | `position: sticky` CSS only; must stay a normal list without CSS or with reduced motion. | M | decision |
| **Hero lights-out intro (B1)** | Merged in PR #9. | **done** | - | - | - |

## 3. Spec claims that conflict with `content/*.ts`

| Spec says | `content/` says | Where |
|---|---|---|
| Projects: **SpendWise** (MERN + Socket.IO), **MindMitra** (FastAPI + React chatbot), **Course Tracker** (React + Node + Postgres/Mongo), **Tutorly** (MERN SaaS, Stripe/Razorpay, OpenAI, Socket.IO), **iPharmaAI 483** (pharma compliance platform) | None of these names exists. `content/projects.ts` has: Sustainability Tracker, Study Tracker, ProFolio, MindCraft, AI Mental Health Chatbot, NexGen Pharma Website, Wanderlust, AI Society Official Website (all `visible: true`), and 2D Platformer Game, 2D Shooter Game (`visible: false`). | `content/projects.ts` `title:` lines |
| `mindmitra.py` "FastAPI + React mental health chatbot" | Closest content entry is "AI Mental Health Chatbot": `stack: ["React", "FastAPI", "Redis", "Docker", "OpenAI API"]`. **I cannot tell whether it is the same project renamed.** | `content/projects.ts` slug `ai-mental-health-chatbot` |
| "Stripe/Razorpay", "Socket.IO", "MERN" as project tech | `grep` finds none of Stripe, Razorpay, Socket.IO in `content/`; "MERN" appears only in `content/papers.ts`. | `content/` search |
| Experience: "Currently just **NexGen Pharma Solutions** (Software Development Intern, Robotics & Intelligent Systems)" | **5 entries:** Software Development Engineer at Praverse Tech (2026-07 to present); Software Development Intern at NexGen (team "Robotics & Intelligent Systems", 2026-01 to 2026-07); Web Developer Intern at NexGen (2025-05 to 2025-07); Full-Stack Developer at PUAISO (2024-07 to 2024-11); Core Coordinator at CDC, Parul University (2022-09 to 2024-12). | `content/experience.ts` |
| Stack to show: Vite, Framer Motion, Redux Toolkit, TanStack Query | Not in `content/skills.ts`. Vite appears once, in Study Tracker's `stack`. | `content/skills.ts`, `content/projects.ts:89` |
| Stack to show: Tailwind, Node/Express, FastAPI, Django, PostgreSQL, Redis, Docker, Qdrant, RAG, JWT | **Present** (as Tailwind CSS, Node.js, Express, FastAPI, Django REST Framework, PostgreSQL, Redis, Docker, Qdrant, RAG pipelines, JWT). | `content/skills.ts` |
| Filter categories `All / Full-stack / AI-ML / Frontend` | No category field on any project. | `content/projects.ts` (`Project` interface) |
| Live GitHub stats | No GitHub numbers anywhere in content (only the profile URL). | `content/site.ts` |
| Site URL `maanavshah.vercel.app` | No site URL in `content/`; it comes from environment variables. | `src/env.ts`, `src/lib/seo.ts` |
| Video or GIF demos (SpendWise loop, MindMitra GIF, Tutorly flow) | `public/assets/` holds 5 images only: `Icon.jpeg`, `nexgen.png`, `puaiso.png`, `shooter.png`, `wanderlust.png`. No videos. | `public/assets/` |

All of the above are **not in content, needs my confirmation**. I added none of them.

## 4. Motion library audit ("name each use where CSS cannot")

- **Result: I found no use that needs a motion library.** `motion` is installed but only `useReducedMotion` is imported (`Reveal.tsx`, `CountUp.tsx`).
- Hover lift and spring feel: CSS transform plus a `linear()` easing. No library.
- Dialog open and close: Radix exposes `data-state`; CSS handles the animation. No library.
- Marquee, rolling text, sticky stack: CSS only.
- Cursor ring: needs per-frame pointer tracking, which CSS cannot do, but plain `requestAnimationFrame` is enough; no library (see `C1-cursor-plan.md`).
- **Only candidate where CSS genuinely falls short:** animating the reflow when the project filter hides or shows cards (a layout animation). I recommend **not** doing it (instant show/hide, or a simple fade) rather than adding a library for it. If you want that animation, that is the one place I would name Framer Motion's `layout` feature, and the View Transitions API is the alternative.

## 5. Window dots: how I would handle your decision

- Red (close) and yellow (minimize) are out. Green becomes "open project details", with a 44 px hit area made by padding around the 11 px dot, not by enlarging it.
- `TrafficLights` is shared with the hero lights-out intro (B1 decisions 6 and 7: "identical to the window dots"). If the windows lose red and yellow, either the hero keeps the three dots (the component stays) and the windows get a separate green-only control, or the intro changes. This needs your call (Q1).
- `CLAUDE.md` says window traffic-light buttons are disabled and `aria-hidden` on touch. A green dot that is the only way into the dialog conflicts with that on phones (Q2).

## 6. Proposed build order (small PRs, one concern each)

Each PR reports: bundle line, CSS and HTML size, LCP/CLS back to back against `main` (the B1 method), the full 7 gates, and mutation tests for its safety rules.

| PR | Delivers | Main risk | Blocked on |
|---|---|---|---|
| **1. Custom cursor ring** (`C1-cursor-plan.md`) | Follower ring on fine pointers only, native cursor untouched, off for reduced motion, forced colors and touch. | A decorative ring that interferes with clicking or low-vision pointer settings; I keep the native cursor to remove that risk. | Q's in the cursor plan |
| **2. B2 rolling-text hover** | `RollLink` on nav links and Contact buttons, CSS only. | Doubled accessible name if the copy is not `aria-hidden`; layout shift from the clipped box. | Q on CTAs |
| **3. Green dot opens project details** | Window dots reworked per Q1, real button with 44 px hit area, Radix dialog with `deep`, `features`, `stack`, `metrics`, links. | Touch rule conflict, focus return, duplicate content next to the inline `<details>`. | Q1, Q2, Q3 |
| **4. Project filter** | `All / Full-stack / AI-ML / Frontend` filter (works without JS if possible). | Wrong categories (content decision); empty-state layout; keeping `content:check` and the Zod schema in step. | Categories from you |
| **5. Skills marquee, second row** | Reverse-direction row from existing skills; same pause control and static fallback. | Two moving strips under WCAG 2.2.2 (each already has a pause control). | Which items |
| **6. Nav: GitHub / LinkedIn icons** | Two icon links in the bar. | Crowding between 760 and 1100 px; 44 px tap targets. | - |
| **7. B3 sticky card stack (Experience)** | CSS-only stack that degrades to the plain list. | Content hidden behind cards; reduced-motion and no-CSS behavior. | Decision |
| **8. Hover demos for projects** | Lazy video on first hover (fine pointer, no reduced motion), `media.video` in the schema. | Needs real videos; autoplay and bandwidth rules. | Videos from you |
| **9. Lighthouse CI (optional)** | Performance and a11y budgets in CI (PLAN.md Phase 7). | Flaky thresholds on CI runners. | Decision |
| **10. Hero extras (optional, only if wanted)** | Terminal card and/or GitHub stats card. | New service, token, rate limits, and facts not in content. | Decision + token |

**Why the cursor is PR 1 (I agree with your default).** It touches no content, needs nothing from you, and later PRs have to know about it: the dialog in PR 3 needs the ring's z-index and hide rules, and PR 2's roll links need to coexist with the ring's hover state. B2 would be the smaller PR, but doing the cursor first means the others are built and tested with it present.

## 7. Open questions for you

1. **Red and yellow dots: remove them from window headers entirely (green only), or keep them as decorative?** Either way, `TrafficLights` is also used by the hero intro, which you asked to be identical to the window dots.
2. **Green dot on touch:** the project rule disables window dots on touch, but green is now the dialog trigger. Keep the existing inline "Deep dive" for touch and make the green dot fine-pointer only, or make it work on touch too?
3. **Dialog vs inline "Deep dive":** keep both (inline for no-JS and touch), or replace the inline details everywhere once the dialog exists?
4. **Project categories** for `All / Full-stack / AI-ML / Frontend`: which category does each of the 8 visible projects get (and can a project be in two)?
5. **The five projects in the spec** (SpendWise, MindMitra, Course Tracker, Tutorly, iPharmaAI 483): are they real projects to be added (you supply the content), is "MindMitra" the "AI Mental Health Chatbot", or is the spec simply stale?
6. **Hover demos:** do you have screen recordings or screenshots, and for which projects? Videos need a size and format limit.
7. **GitHub stats card:** do you want it at all (it needs a token, caching and new numbers)?
8. **Hero:** keep the 3D cube (my recommendation), or replace it with a window collage?
9. **Nav:** add GitHub/LinkedIn icons (PR 6), and confirm skipping the transparent-to-blur scroll behavior.
10. **Skills content:** Redux Toolkit, TanStack Query, Framer Motion and Vite are in the spec but not in `content/skills.ts`. Should any be added to your stack list (you confirm)?
11. **Experience:** confirm the 5 roles in `content/experience.ts` are the truth and the spec's "just NexGen" is stale, and whether you want B3.
12. **Order:** is cursor-first, then B2, then the dialog and filter the order you want?
13. **Lighthouse CI:** when, and what thresholds?

## 8. Not done / uncertain

- Nothing in this document was measured except the baseline gates; costs of future PRs are estimates until each is built.
- I did not read the old Vite site or `maanavshah.vercel.app`; the "current state" is the repository only.
- I could not verify what the old Vite site contained, so "spec is stale" is a likelihood, not a fact. Your confirmation (Q5, Q11) settles it.
